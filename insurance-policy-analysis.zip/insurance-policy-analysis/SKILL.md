---
name: insurance-policy-analysis
description: >
  This skill should be used when analyzing Chinese life insurance policies for surrender vs reduced paid-up (RPU/减额缴清) decisions.
  It covers PDF policy data extraction, lifetime expected present value (EPV) calculation using CLT mortality tables,
  multi-scenario interest rate path analysis, and interactive HTML report generation.
  Trigger when the user mentions insurance policy analysis, surrender evaluation, 减额缴清, RPU, 保单分析, 退保,
  保险精算, EPV calculation, or rate path scenario analysis for insurance decisions.
agent_created: true
---

# Insurance Policy Analysis — 退保 vs 减额缴清

Comprehensive actuarial analysis skill for Chinese life insurance policy decision-making:
surrender vs reduced paid-up (RPU/减额缴清) with lifetime EPV, multi-rate-path scenarios, and HTML reporting.

## When to Use

This skill applies whenever the user asks to:

- Analyze whether to surrender (退保) or convert to reduced paid-up (减额缴清) for a Chinese insurance policy
- Calculate the expected present value (EPV) of insurance benefits
- Run interest rate sensitivity or multi-scenario analysis for policy decisions
- Generate a policy decision report with charts

## Workflow

### Phase 1: Data Extraction

Extract policy data from PDF contracts using pymupdf (fitz):

```python
import fitz
doc = fitz.open("policy.pdf")
for page in doc:
    text = page.get_text()
    # Parse cash value tables, coverage amounts, premium schedules
```

Key data points to extract for each policy:
- Current cash value (CV)
- Annual premium
- RPU death benefit (减额缴清身故保额)
- RPU CI total (减额缴清重疾总额)
- Insured age and gender

### Phase 2: EPV Calculation

Use `scripts/policy_epv_calc.py` as the calculation engine:

```bash
# Single discount rate
python scripts/policy_epv_calc.py --discount 0.03 --mort-adj 0.80 --json

# Sensitivity analysis
python scripts/policy_epv_calc.py --sensitivity --json
```

**CRITICAL RULES (learned from past errors):**

1. EPV MUST be calculated over the FULL LIFETIME (to age 105), NOT truncated to remaining policy years.
   RPU provides lifetime coverage; truncating to 12-year policy term underestimates EPV by 10-20x.

2. Before age 18, death benefit is limited to cash value (Chinese insurance law restricts minor death benefits).
   After age 18, use the actual RPU face amount.

3. The discount rate (d) for EPV represents opportunity cost of capital and moves in the SAME direction
   as market interest rates. When rates fall, d falls, and future benefit PV rises.

### Phase 3: Rate Path Scenario Analysis

Use `scripts/rate_path_decision.py` for multi-scenario analysis:

```bash
python scripts/rate_path_decision.py
```

This script:
1. Runs 4 predefined interest rate paths with probability weights
2. Builds a d x r decision matrix (8 discount rates x 5 investment returns)
3. Generates EPV sensitivity curves
4. Produces an interactive HTML report with Chart.js visualizations

The 4 default rate paths:
| Path | Probability | d | r | Description |
|:---|:---|:---|:---|:---|
| deep_low | 15% | 0.8% | 1.5% | Japan-style persistent low rates |
| gradual_low | 50% | 1.5% | 2.5% | Gradual decline (baseline) |
| stable_current | 25% | 2.0% | 3.0% | Rates hold at current levels |
| moderate_recovery | 10% | 2.5% | 3.5% | Mild recovery |

Each path analyzes: d (discount rate = 10Y CGB + risk premium) and r (investment return = actual achievable return).

### Phase 4: Decision Framework

Core decision formula (excluding premium savings, which are identical in both scenarios):

```
净差 = CV * (1+r)^n - RPU残值 - EPV_total * (1+d)^n
```

Interpretation:
- 净差 > 2000 → Surrender is better
- -2000 ≤ 净差 ≤ 2000 → Borderline, consider non-financial factors
- 净差 < -2000 → RPU is better

Also compute probability-weighted net advantage:
```
加权净优势 = sum(path_prob_i * net_diff_i)
```

### Phase 5: Report Generation

The HTML report includes:
- Rate path comparison cards with probabilities
- Bar chart: Surrender FV vs RPU FV for each path
- Decision matrix (d x r grid) with color-coded cells
- EPV sensitivity line chart (life + CI breakdown)
- Probability-weighted final recommendation banner

## Reference Documents

Load these as needed during analysis:

- `references/methodology.md` — Full mathematical formulas, decision framework, and common pitfalls
- `references/actuarial_data.md` — CL1(2010-2013) male mortality table, CI incidence rates by age group, minor death benefit limits, current Chinese interest rate benchmarks

## Key Parameters

| Parameter | Default | Description |
|:---|:---|:---|
| mort_adj | 0.80 | Mortality adjustment (CLT2025 = 20% lower than CL1) |
| MAX_AGE | 105 | End of life table |
| cv_growth | 3.5% | Pre-18 cash value growth rate assumption |
| POLICY_YEARS | 12 | Remaining premium payment period |
| RPU_RESIDUAL | varies | Residual cash value after RPU conversion |

## Non-Financial Factors

When the decision is borderline, consider:
- Family's existing insurance coverage (redundant RPU may have low marginal value)
- Liquidity needs (cash-in-hand vs locked insurance benefit)
- Health status of insured (higher-than-average mortality risk makes RPU more valuable)
- Tax and estate planning considerations

## Integration with Other Skills

- Use `pm-project-opportunity` skill's framework for evaluating insurance as an "investment project"
- Use `pm-bid-proposal` skill for structuring the analysis report in a government/enterprise format
